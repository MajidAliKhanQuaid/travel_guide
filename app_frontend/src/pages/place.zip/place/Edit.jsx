import { useEffect, useState } from "react";
import { useParams } from "react-router";
import axios from "./../../interceptor";
import history from "./../../History";
import { Container, Form, Button, Figure } from "react-bootstrap";
const EditPlace = () => {
  const { identifier } = useParams();
  const [place, setPlace] = useState({
    _id: "",
    name: "",
    location: "",
    images: [],
  });
  useEffect(() => {
    axios
      .get(`/places/get?id=${identifier}`)
      .then(function ({ data }) {
        setPlace(data);
      })
      .catch(function (response) {
        //handle error
        console.log(response);
      });
  }, []);

  const submitForm = (event) => {
    event.preventDefault();
    axios({
      method: "post",
      url: "/places/update",
      data: place,
    })
      .then(({ data }) => {
        history.push("/places");
      })
      .catch((err) => {});
  };

  const imageRemoveContainer = (x) => {
    return (
      <>
        <Button>x</Button>
        <Figure style={{ margin: "10px 10px 0px 0px" }}>
          <Figure.Image
            style={{ height: "80px", width: "100px" }}
            alt={"http://localhost:4000/uploads/" + x}
            src={"http://localhost:4000/uploads/" + x}
          />
        </Figure>
      </>
    );
  };

  return (
    <>
      <Container>
        <Form onSubmit={submitForm}>
          <Form.Control
            name="_id"
            type="hidden"
            value={place._id}
            onChange={(e) => {
              setPlace({ ...place, _id: e.target.value });
            }}
          />
          <Form.Group controlId="name">
            <Form.Label>Name</Form.Label>
            <Form.Control
              name="name"
              type="text"
              value={place.name}
              onChange={(e) => {
                setPlace({ ...place, name: e.target.value });
              }}
              placeholder="Enter Name ..."
            />
            {/* <Form.Text className="text-muted">
              We'll never share your email with anyone else.
            </Form.Text> */}
          </Form.Group>

          <Form.Group controlId="description">
            <Form.Label>Description</Form.Label>
            <Form.Control
              name="description"
              as="textarea"
              rows={3}
              value={place.description}
              onChange={(e) => {
                setPlace({ ...place, description: e.target.value });
              }}
              placeholder="Enter Description ..."
            />
            {/* <Form.Text className="text-muted">
              We'll never share your email with anyone else.
            </Form.Text> */}
          </Form.Group>

          <Form.Group controlId="location">
            <Form.Label>Location</Form.Label>
            <Form.Control
              name="location"
              type="text"
              value={place.location}
              onChange={(e) => {
                setPlace({ ...place, location: e.target.value });
              }}
              placeholder="Enter Location ..."
            />
            {/* <Form.Text className="text-muted">
              We'll never share your email with anyone else.
            </Form.Text> */}
          </Form.Group>

          <Form.Group controlId="images">
            <Form.Label>Gallery</Form.Label>
            <div className="galleryContainer">
              <Form.Control
                name="images"
                className="galleryImage"
                type="file"
                placeholder="Add Image file ..."
                multiple="multiple"
              />
              {place.images.map((x) => (
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <div style={{ position: "absolute" }}>
                    <Button
                      style={{
                        position: "relative",
                        fontSize: "10px",
                        padding: "5px 10px",
                        borderRadius: "50%",
                        left: "85px",
                        top: "-5px",
                      }}
                    >
                      x
                    </Button>
                  </div>

                  <Figure style={{ margin: "10px 10px 0px 0px" }}>
                    <Figure.Image
                      style={{ height: "80px", width: "100px" }}
                      alt={"http://localhost:4000/uploads/" + x}
                      src={"http://localhost:4000/uploads/" + x}
                    />
                  </Figure>
                </div>
              ))}
            </div>
            {/* <Form.Text className="text-muted">
              We'll never share your email with anyone else.
            </Form.Text> */}
          </Form.Group>

          {/* <Form.Group controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" placeholder="Password" />
          </Form.Group>
          <Form.Group controlId="formBasicCheckbox">
            <Form.Check type="checkbox" label="Check me out" />
          </Form.Group> */}
          <Button variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </Container>
    </>
  );
};

export default EditPlace;
