import { useDispatch, useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";
import axios from "./../../interceptor";
import { toggleSearchButton, toggleSpinner } from "./../../helper";

const { useState, useEffect } = require("react");
const { Container, Table } = require("react-bootstrap");

const SearchPlaces = (props) => {
  const query = useParams();
  const dispatch = useDispatch();
  const searchText = useSelector((x) => x.commonState.searchText);
  // alert(searchText);
  const [places, setPlaces] = useState([]);

  const searchPlaces = () => {
    if (searchText) {
      toggleSpinner(dispatch, true);
      axios
        .post("/places/search", { query: searchText })
        .then(({ data }) => {
          setPlaces(data);
          toggleSpinner(dispatch, false);
        })
        .catch((err) => {
          toggleSpinner(dispatch, false);
        });
    } else {
      console.error("Search Text ", searchText);
    }
  };

  useEffect(() => {
    searchPlaces();
    toggleSearchButton(dispatch, false);
  }, []);

  if (places.length == 0) {
    return <h1>No results found for `{searchText}` !</h1>;
  }

  return (
    <>
      <Container>
        <h1>Search results for `{searchText}`</h1>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Location</th>
              <th>Description</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {places.map((x, i) => (
              <tr>
                <td>{i + 1}</td>
                <td>{x.name}</td>
                <td>{x.location}</td>
                <td>{x.description}</td>
                <td>
                  <Link to="">X</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Container>
    </>
  );
};
export default SearchPlaces;
